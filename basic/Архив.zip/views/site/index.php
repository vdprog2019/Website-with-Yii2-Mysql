<?php

/* @var $model app\models\IndexForm*/

$this->title = 'My Yii Application';
$this->registerCssFile('css/site.css');
$this->registerJsFile('js/site.js');
?>
<div class="container">

</div>